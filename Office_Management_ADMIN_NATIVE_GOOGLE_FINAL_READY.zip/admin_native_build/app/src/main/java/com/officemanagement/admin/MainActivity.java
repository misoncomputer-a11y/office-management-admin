package com.officemanagement.admin;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.GoogleAuthProvider;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private WebView webView;
    private TextView status;
    private CredentialManager credentialManager;
    private final Executor executor = Executors.newSingleThreadExecutor();
    private static final String ADMIN_UID = "J22xtnPUwNYYF40kpQQauXcWAW32";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        credentialManager = CredentialManager.create(this);
        showLogin();
        if (auth.getCurrentUser() != null && ADMIN_UID.equals(auth.getCurrentUser().getUid())) {
            loadAdmin();
        }
    }

    private void showLogin() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(48,80,48,48);
        TextView title = new TextView(this); title.setText("Office Management Admin"); title.setTextSize(26); title.setTextColor(Color.BLACK);
        status = new TextView(this); status.setText("Google account দিয়ে Admin যাচাই করুন"); status.setTextSize(16); status.setPadding(0,32,0,32);
        Button login = new Button(this); login.setText("Continue with Google");
        box.addView(title); box.addView(status); box.addView(login); setContentView(box);
        login.setOnClickListener(v -> signInGoogle());
    }

    private void signInGoogle() {
        status.setText("Google sign-in চালু হচ্ছে...");
        // Firebase Android setup requires the project's Web OAuth client ID in google-services.json.
        String serverClientId = getString(com.officemanagement.admin.R.string.default_web_client_id);
        GetGoogleIdOption option = new GetGoogleIdOption.Builder()
                .setServerClientId(serverClientId)
                .setFilterByAuthorizedAccounts(false)
                .build();
        GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
        credentialManager.getCredentialAsync(this, request, null, executor, new androidx.credentials.CredentialManagerCallback<GetCredentialResponse, androidx.credentials.exceptions.GetCredentialException>() {
            @Override public void onResult(GetCredentialResponse response) { runOnUiThread(() -> handleCredential(response.getCredential())); }
            @Override public void onError(androidx.credentials.exceptions.GetCredentialException e) { runOnUiThread(() -> status.setText("Google login failed: " + e.getMessage())); }
        });
    }

    private void handleCredential(Credential credential) {
        if (!(credential instanceof CustomCredential)) { status.setText("Google credential পাওয়া যায়নি।"); return; }
        CustomCredential c = (CustomCredential) credential;
        if (!GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) { status.setText("Google ID token পাওয়া যায়নি।"); return; }
        try {
            GoogleIdTokenCredential google = GoogleIdTokenCredential.createFrom(c.getData());
            String idToken = google.getIdToken();
            AuthResultTask(idToken);
        } catch (GoogleIdTokenParsingException e) { status.setText("Google token invalid."); }
    }

    private void AuthResultTask(String idToken) {
        auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null)).addOnCompleteListener(this, task -> {
            if (!task.isSuccessful()) { status.setText("Firebase authentication failed."); return; }
            if (auth.getCurrentUser() == null || !ADMIN_UID.equals(auth.getCurrentUser().getUid())) {
                auth.signOut(); status.setText("এই Google account Admin account নয়।"); return;
            }
            loadAdminWithToken(idToken);
        });
    }

    private void loadAdmin() {
        // Existing Firebase session is already trusted by native Firebase Auth.
        auth.getCurrentUser().getIdToken(true).addOnSuccessListener(r -> loadAdminWithToken(r.getToken()));
    }

    private void loadAdminWithToken(String idToken) {
        webView = new WebView(this);
        WebSettings s = webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        setContentView(webView); webView.loadUrl("file:///android_asset/admin.html");
        webView.postDelayed(() -> webView.evaluateJavascript("window.nativeFirebaseIdToken=" + org.json.JSONObject.quote(idToken) + "; window.dispatchEvent(new Event('nativeFirebaseReady'));", null), 500);
    }

    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
