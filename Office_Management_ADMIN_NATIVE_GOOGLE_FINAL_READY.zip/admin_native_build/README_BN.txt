OFFICE MANAGEMENT — ADMIN NATIVE GOOGLE

এটি HopWeb HTML project নয়। এটি একটি Native Android Studio project.
Google Login Android-এর Credential Manager দিয়ে হবে; WebView-এর ভিতরে Google OAuth চালানো হবে না।

Firebase configuration:
- Project ID: office-management-99273
- Android package: com.officemanagement.admin
- Firebase Android app is already configured with this package.
- google-services.json is included in app/.

BUILD:
1) Android Studio-তে admin_native_build folder open করুন।
2) Project sync শেষ হতে দিন।
3) app/google-services.json আগে থেকেই আছে—আবার বসানোর দরকার নেই।
4) Firebase Console-এ Android app-এর SHA-1 certificate fingerprint যোগ করুন (আপনার build/signing key অনুযায়ী)।
5) Build > Build APK(s) চাপুন।
6) তৈরি APK ফোনে install করুন।

LOGIN FLOW:
Native Google account selection -> Firebase Authentication -> Admin UID verification -> Admin Panel -> Admin PIN.
Admin UID allowed by the app: J22xtnPUwNYYF40kpQQauXcWAW32

IMPORTANT:
- এই project HopWeb-এর WebView import হিসেবে ব্যবহার করবেন না।
- Google Login-এর জন্য Android native authentication দরকার।
- Firebase Realtime Database-এর secure rules আগের মতোই রাখুন; public .read/.write true করে সমস্যা ঠিক করার চেষ্টা করবেন না।
